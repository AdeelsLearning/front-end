import { TestBed } from '@angular/core/testing';

import { FamilyDetailsService } from './family-details.service';

describe('FamilyDetailsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: FamilyDetailsService = TestBed.get(FamilyDetailsService);
    expect(service).toBeTruthy();
  });
});
