import { Injectable } from '@angular/core';
import {User} from "../_models/model.user"; 
import {AppComponent} from "../app.component"; 
import { HttpClient } from "@angular/common/http";
import {Router} from "@angular/router";
@Injectable()
export class AccountService { 
  users: User[] = [];  
  constructor(private httpClient:HttpClient, public router: Router) { } 
  createAccount(user:User){
    return this.httpClient.post(AppComponent.API_URL+'/account/register',user); 
  } 
  getAll() {
      return this.httpClient.get<User[]>(AppComponent.API_URL+'/account/users');
  }  
  delete(id: number) { 
      return this.httpClient.delete(AppComponent.API_URL+'/account/users/'+id);
   } 
  updateUser(user: User) {
    return this.httpClient.put(AppComponent.API_URL+'/account/users/'+ user.id, user);
  } 
  getUserById(id: number) {
    return this.httpClient.get<User>(AppComponent.API_URL +'/account/users/' + id);
  }
}
  