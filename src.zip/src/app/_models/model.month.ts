export class Month { 
    monthId : string;
    monthCode: string="";
    monthDesc: string="";
    createdWhen: string="";
    createdBy: string="";
    modifyWhen: string="";
    modifyBy: string="";
    monthActive: boolean;
 
}