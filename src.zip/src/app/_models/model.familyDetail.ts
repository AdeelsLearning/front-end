export class FamilyDetail { 
    patientId : string;
    memberId : string;
    memberName: string="";
    memberAge: string="";
    memberRelation: string="";
    memberHealthy: string="";
    memberDisease: string=""; 
 
}