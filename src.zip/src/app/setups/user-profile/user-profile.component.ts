import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormGroup,Validators,FormControl} from '@angular/forms'; 
export interface Gender {
  name: string;
  value: string;
}
@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})
export class UserProfileComponent implements OnInit {
  isLinear = false;
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;
  thirdFormGroup: FormGroup; 

  constructor(private _formBuilder: FormBuilder) {}

  ngOnInit() {
    this.firstFormGroup = this._formBuilder.group({
      firstCtrl: ['', Validators.required]
    });
    this.secondFormGroup = this._formBuilder.group({
      secondCtrl: ['', Validators.required]
    });
    this.thirdFormGroup = this._formBuilder.group({
      thirdCtrl: ['', Validators.required]
    });
  }
  submit(){
   alert('submitted');
  }
  genderControl = new FormControl('', [Validators.required]);
  genders: Gender[] = [
    {name: 'Male', value: 'Male'},
    {name: 'Female', value: 'Female'} 
  ];
}
