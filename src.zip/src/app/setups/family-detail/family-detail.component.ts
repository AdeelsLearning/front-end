import { Component, OnInit ,ViewChild} from '@angular/core';   
import {Router} from "@angular/router";
import { AccountService } from '../../_services/account.service';
import { FamilyDetail } from "../../_models/model.familyDetail";
import {MatPaginator, MatSort, MatTableDataSource} from '@angular/material'; 
import * as jspdf from 'jspdf';   
import html2canvas from 'html2canvas';  
import {ExcelService} from '../../_services/excel.service';
import { FamilyDetailsService } from '../../_services/family-details.service';  

@Component({ 
  selector: 'app-family-detail',
  templateUrl: './family-detail.component.html',
  styleUrls: ['./family-detail.component.css']
})
export class FamilyDetailComponent implements OnInit {
  details: FamilyDetail = new FamilyDetail(); 
  displayedColumns = ['actions', 'Name', 'Age','Relation','Healthy','Disease'];
  dataSource: MatTableDataSource<FamilyDetail>;
  currentUser: FamilyDetail;
  familyDetails: FamilyDetail[] = [];  
 
  patientId : string;
  memberId : string;
  memberName: string="";
  memberAge: string="";
  memberRelation: string="";
  memberHealthy: string="";
  memberDisease: string=""; 

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort; 
	constructor(private router: Router,private familyDetailService:FamilyDetailsService,private excelService:ExcelService) { 
    this.currentUser = JSON.parse(localStorage.getItem('currentUser'));  
  }   

  ngOnInit() {
    this.loadAll(); 
  } 



deleteClick(memberId: string,memberName:String) {
/*   if(confirm("Are you sure to delete "+memberName)) { 
    this.familyDetailService.delete(memberId).subscribe(
      data => {
        this.loadAll();
      },
      error => {
          console.log("Error", error);
      });  
  } */
}     

addClick(): void {  
  // this.router.navigate(['auth/setups/months-add']);
}; 
editClick(familyDetail: FamilyDetail): void {
  localStorage.removeItem("editId");
 // localStorage.setItem("editUserId", user.id.toString());
  localStorage.setItem('editId', JSON.stringify(familyDetail.memberId));
  // this.router.navigate(['auth/setups/months-edit']);
}; 
private loadAll() {
/*     this.familyDetailService.getAll().subscribe(
      data => {
        this.familyDetails = data;  
        this.dataSource = new MatTableDataSource(this.familyDetails);
        this.ngAfterViewInit(); 
      },
      error => {
          console.log("Error", error);
      });  */
}  
ngAfterViewInit() {
  this.dataSource.paginator = this.paginator;
  this.dataSource.sort = this.sort;
  } 
 selectedRowIndex: number = -1; 
 rowClick(row){
    this.selectedRowIndex = row.memberId;
  }  
  addElement() { 
    this.familyDetails.push({patientId:"0001",memberId:"0001",memberName:this.memberName,
                             memberAge:this.memberAge,memberRelation:this.memberRelation,
                             memberHealthy:this.memberHealthy,memberDisease:this.memberDisease})
    this.dataSource = new MatTableDataSource(this.familyDetails);  
  }
}